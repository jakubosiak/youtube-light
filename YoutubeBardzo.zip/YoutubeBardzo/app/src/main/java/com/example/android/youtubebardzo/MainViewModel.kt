package com.example.android.youtubebardzo

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel(){

}