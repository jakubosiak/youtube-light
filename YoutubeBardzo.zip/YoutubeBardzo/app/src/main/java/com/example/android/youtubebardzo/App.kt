package com.example.android.youtubebardzo

import androidx.multidex.MultiDexApplication

class App : MultiDexApplication(){

}